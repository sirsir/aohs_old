module Arel
  module Nodes
    class Assignment < Arel::Nodes::Binary
    end
  end
end
