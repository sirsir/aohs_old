require 'arjdbc/jdbc'
jdbc_require_driver 'jdbc/sqlite3'
require 'arjdbc/sqlite3/connection_methods'
require 'arjdbc/sqlite3/adapter'
