module Arel
  module Nodes
    class UnionAll < Arel::Nodes::Binary
    end
  end
end

