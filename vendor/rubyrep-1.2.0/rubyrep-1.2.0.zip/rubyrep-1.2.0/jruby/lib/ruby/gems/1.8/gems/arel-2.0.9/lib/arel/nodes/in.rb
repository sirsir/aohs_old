module Arel
  module Nodes
    class In < Equality
    end
  end
end
