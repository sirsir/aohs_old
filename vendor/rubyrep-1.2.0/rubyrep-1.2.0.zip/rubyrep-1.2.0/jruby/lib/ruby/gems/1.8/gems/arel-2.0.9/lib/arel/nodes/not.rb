module Arel
  module Nodes
    class Not < Arel::Nodes::Unary
    end
  end
end
