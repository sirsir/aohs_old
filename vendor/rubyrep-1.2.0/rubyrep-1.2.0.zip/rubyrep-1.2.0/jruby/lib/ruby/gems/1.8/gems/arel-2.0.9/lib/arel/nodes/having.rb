module Arel
  module Nodes
    class Having < Arel::Nodes::Unary
    end
  end
end
