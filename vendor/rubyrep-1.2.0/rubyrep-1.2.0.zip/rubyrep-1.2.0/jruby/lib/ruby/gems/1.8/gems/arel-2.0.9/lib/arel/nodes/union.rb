module Arel
  module Nodes
    class Union < Arel::Nodes::Binary
    end
  end
end

