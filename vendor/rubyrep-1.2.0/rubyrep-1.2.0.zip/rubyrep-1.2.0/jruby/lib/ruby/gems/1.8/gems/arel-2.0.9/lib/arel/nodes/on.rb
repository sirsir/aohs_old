module Arel
  module Nodes
    class On < Arel::Nodes::Unary
    end
  end
end
