module Arel
  module Nodes
    class GreaterThanOrEqual < Arel::Nodes::Binary
    end
  end
end
