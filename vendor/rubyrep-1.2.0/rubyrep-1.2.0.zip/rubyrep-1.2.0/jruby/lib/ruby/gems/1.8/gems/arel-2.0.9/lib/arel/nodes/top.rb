module Arel
  module Nodes
    class Top < Arel::Nodes::Unary
    end
  end
end
