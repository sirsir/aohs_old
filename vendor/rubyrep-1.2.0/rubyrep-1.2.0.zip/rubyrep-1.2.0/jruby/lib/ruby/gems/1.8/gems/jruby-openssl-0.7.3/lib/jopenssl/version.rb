module Jopenssl
  module Version
    VERSION = "0.7.3"
  end
end
