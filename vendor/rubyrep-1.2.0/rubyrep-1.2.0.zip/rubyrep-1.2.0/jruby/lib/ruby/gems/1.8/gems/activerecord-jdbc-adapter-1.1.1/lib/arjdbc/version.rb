module ArJdbc
  module Version
    VERSION = "1.1.1"
  end
end
# Compatibility with older versions of ar-jdbc for other extensions out there
JdbcAdapter = ArJdbc
JdbcSpec = ArJdbc
