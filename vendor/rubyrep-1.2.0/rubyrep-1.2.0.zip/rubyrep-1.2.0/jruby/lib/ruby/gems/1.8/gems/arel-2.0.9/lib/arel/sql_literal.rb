module Arel
  class SqlLiteral < Nodes::SqlLiteral
  end
end
