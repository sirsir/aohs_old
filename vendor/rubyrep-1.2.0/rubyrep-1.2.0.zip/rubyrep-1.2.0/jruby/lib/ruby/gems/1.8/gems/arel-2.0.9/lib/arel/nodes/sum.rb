module Arel
  module Nodes
    class Sum < Arel::Nodes::Function
    end
  end
end
