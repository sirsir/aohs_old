module Arel
  module Nodes
    class DoesNotMatch < Arel::Nodes::Binary
    end
  end
end
