module Arel
  module Nodes
    class LessThan < Arel::Nodes::Binary
    end
  end
end
