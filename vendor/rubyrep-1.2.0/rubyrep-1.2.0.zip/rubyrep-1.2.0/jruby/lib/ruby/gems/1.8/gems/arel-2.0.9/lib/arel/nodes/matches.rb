module Arel
  module Nodes
    class Matches < Arel::Nodes::Binary
    end
  end
end
