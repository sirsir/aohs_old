module Arel
  module Nodes
    class GreaterThan < Arel::Nodes::Binary
    end
  end
end
