module Arel
  module Nodes
    class Max < Arel::Nodes::Function
    end
  end
end
