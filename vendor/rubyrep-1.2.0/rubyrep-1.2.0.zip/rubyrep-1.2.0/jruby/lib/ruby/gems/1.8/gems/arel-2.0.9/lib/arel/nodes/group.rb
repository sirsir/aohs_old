module Arel
  module Nodes
    class Group < Arel::Nodes::Unary
    end
  end
end
