module Arel
  module Nodes
    class Except < Arel::Nodes::Binary
    end
  end
end

