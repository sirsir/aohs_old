module Arel
  module Nodes
    class Avg < Arel::Nodes::Function
    end
  end
end
