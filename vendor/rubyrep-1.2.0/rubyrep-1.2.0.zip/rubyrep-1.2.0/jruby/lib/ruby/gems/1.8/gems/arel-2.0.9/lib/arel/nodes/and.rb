module Arel
  module Nodes
    class And < Arel::Nodes::Binary
    end
  end
end
