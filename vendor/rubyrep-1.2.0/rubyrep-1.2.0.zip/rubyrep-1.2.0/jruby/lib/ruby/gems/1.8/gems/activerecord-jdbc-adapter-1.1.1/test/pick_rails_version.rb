# Specify version of activerecord with ENV['AR_VERSION'] if desired
gem 'rails', ENV['AR_VERSION'] if ENV['AR_VERSION']
require 'active_record/version'
