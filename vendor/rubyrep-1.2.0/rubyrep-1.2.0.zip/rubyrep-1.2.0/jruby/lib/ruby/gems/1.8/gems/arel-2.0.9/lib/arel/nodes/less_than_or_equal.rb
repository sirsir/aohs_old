module Arel
  module Nodes
    class LessThanOrEqual < Arel::Nodes::Binary
    end
  end
end
