module Arel
  module Nodes
    class Limit < Arel::Nodes::Unary
    end
  end
end

