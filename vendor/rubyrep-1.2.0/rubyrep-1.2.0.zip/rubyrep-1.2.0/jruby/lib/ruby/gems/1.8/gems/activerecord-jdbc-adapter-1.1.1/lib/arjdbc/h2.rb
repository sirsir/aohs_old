require 'arjdbc/jdbc'
jdbc_require_driver 'jdbc/h2'
require 'arjdbc/h2/connection_methods'
require 'arjdbc/h2/adapter'
