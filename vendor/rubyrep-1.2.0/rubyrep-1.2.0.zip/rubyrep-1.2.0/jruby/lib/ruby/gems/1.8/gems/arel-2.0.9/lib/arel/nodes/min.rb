module Arel
  module Nodes
    class Min < Arel::Nodes::Function
    end
  end
end
