module Arel
  module Nodes
    class Intersect < Arel::Nodes::Binary
    end
  end
end

