module Arel
  module Nodes
    class Or < Arel::Nodes::Binary
    end
  end
end
