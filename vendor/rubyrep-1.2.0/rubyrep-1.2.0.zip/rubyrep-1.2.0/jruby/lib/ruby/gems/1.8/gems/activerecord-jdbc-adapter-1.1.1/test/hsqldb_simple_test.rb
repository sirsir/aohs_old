require 'jdbc_common'
require 'db/hsqldb'

class HsqldbSimpleTest < Test::Unit::TestCase
  include SimpleTestMethods
end
