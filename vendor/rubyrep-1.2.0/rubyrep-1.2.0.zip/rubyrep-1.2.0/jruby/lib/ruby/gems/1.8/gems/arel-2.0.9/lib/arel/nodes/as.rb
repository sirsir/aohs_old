module Arel
  module Nodes
    class As < Arel::Nodes::Binary
    end
  end
end
