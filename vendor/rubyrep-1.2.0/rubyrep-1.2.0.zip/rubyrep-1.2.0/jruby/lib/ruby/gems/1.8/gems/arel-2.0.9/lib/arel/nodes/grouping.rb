module Arel
  module Nodes
    class Grouping < Arel::Nodes::Unary
    end
  end
end
