module Arel
  module Nodes
    class Between < Arel::Nodes::Binary
    end
  end
end
