require 'arjdbc/jdbc'
jdbc_require_driver 'jdbc/derby'
require 'arjdbc/derby/connection_methods'
require 'arjdbc/derby/adapter'



