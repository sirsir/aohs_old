module Arel
  module SqlCompiler
    class DerbyCompiler < GenericCompiler
    end
  end
end
