require 'arjdbc/jdbc'
jdbc_require_driver 'jdbc/jtds', 'jdbc-mssql'
require 'arjdbc/mssql/connection_methods'
require 'arjdbc/mssql/adapter'
