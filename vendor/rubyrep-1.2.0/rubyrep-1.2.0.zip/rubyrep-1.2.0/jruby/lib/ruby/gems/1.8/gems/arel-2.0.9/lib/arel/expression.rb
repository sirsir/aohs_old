module Arel
  module Expression
  end
end
