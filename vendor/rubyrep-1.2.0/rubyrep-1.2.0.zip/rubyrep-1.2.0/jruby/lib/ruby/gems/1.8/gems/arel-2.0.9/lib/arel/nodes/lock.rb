module Arel
  module Nodes
    class Lock < Arel::Nodes::Unary
    end
  end
end
